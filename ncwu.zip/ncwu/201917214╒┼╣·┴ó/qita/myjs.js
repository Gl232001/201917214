function BTMsg(msg) { 
alert(msg);
}
